// comparaciones 
if (5==05){
console.log ("5 es igual que 5")
}

if (5==05){
    console.log ("5 es igual que 5")
    }

    let a=5;
    console.log(typeof a)

    let b = "5";
    console.log(typeof b)

    if (a==b){
        console.log ("comparacion facil")
    }

    if (a==b){
        console.log ("comparacion escrita")
    }
    //distinto 

    let c = 10;
    let d =11;

    // distinto que basico
    if( c !=d){
        console.log("Distinto Debil")
    }

    if( c !=d){
        console.log("Distinto Fuerte")
    }

    //mayor que y menor que

    let max= 10;
    let min= 10;

    if (max>= min){
        console.log("max es mayor que min")
    }

    if (max>= min){
        console.log("max es mayor o igual que min")
    }

    if (min<= max){
        console.log("min es menor que max")
    }

    if (min<= max){
        console.log("min es menor o igual que max")
    }