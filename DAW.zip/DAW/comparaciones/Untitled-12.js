//FOR - bucle


//for


/**for estructura
 * for(inicializacion; condicion; actualizacion;)
 * bucle
 * i = i + i;
 * i += 1;
 * i++
 * i--
 */

/for 

for(let i = 0; i<10; i++){
    console.log(i); 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
}

let lista= [1, 2, 3, 4, 5, 6];
for(let = 0;i)
    
//for...of

//forEach

//for...in