//if else + if-else
let q1 =10;

if(q1 ===10){
    console.log("buen trabajo"); "buen trabajo"
}else if(q1 ===9){
    console.log("casi perfecto");
}else if(q1 ===8){
        console.log("bien supongo");
}else if(q1 ===7){
        console.log("estudiale");
}else if(q1 ===6){
        console.log("mejor 6 en ing que 10 en lic");
}else if(q1 ===5){
    console.log("cambiate de carrera");
}else{
console.log("error");
}

    