//BIFURCACIONES if -else
if(true){
    console.log("es verdadero"); "es verdadero"
}
if (true){
    console.log("es verdadero"); "es verdadero"
}else { 
    console.log("es falso"); "es falso"
}

let edad=15;
let legal=18;
if (edad >= legal){
}else{
    console.log("es delito");"es delito"
}
