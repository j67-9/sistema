switch (q1){
    case 10;
     console.log("buen trabajo"); "buen trabajo"
     break;
     case 9;
     console.log("casi perfecto"); 
     break;
     case 8;
     console.log("bien supongo"); 
     break;
     case 7;
     console.log("estudia mas"); 
     break;
     case 6;
     console.log("esfuerzate"); 
     break;
     case 5;
     console.log("mejor 6"); 
     break;
}
