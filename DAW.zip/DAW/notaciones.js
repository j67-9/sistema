//Notaciones
//; --> Delimitar al final de una linea de codigo
//IMPORTANTE no siempre se requiere pa JS
const a = 1
a;

//, -->Acceder a los atributos de un objeto
//Ejemplo
//alumno.edad;

//() --> parenthesis
//function primedio(a, b, c, d){
    //contenido de una funcion }
//if(a > b){ //proceso del if}*/

//[] --> square brakets
//listas arrays
//Ejemplo
//Declarar
const ar = [1, 2, 3, 4, 5];
//Acceder
ar[2];
console.log(ar[2]);

//{} --> curly brackets
//objetos, funciones y estructuras
//ejemplo
const alumno = {
    edad = 15,
    estatura = 1.70,
}