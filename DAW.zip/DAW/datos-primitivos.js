//Datos primitivos
//Number
18;

//string
"Hola Mundo"
`Hola Mundo`
'Hola Mundo'

//booleanos
true;
false;

null;
undefined; //no definido 